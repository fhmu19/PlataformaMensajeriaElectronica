from datetime import datetime
from flask import Flask, render_template, request
import hashlib
import controlador
import envioemail

app = Flask(__name__)
email_origen=""

@app.route("/")
def hello_world():
    return render_template("login.html")

@app.route("/validarUsuario", methods=["GET", "POST"])
def validarUsuario():
    if request.method=="POST":
        usu=request.form["txtusuario"]
        passw=request.form["txtpass"]  
        passw2=passw.encode() 
        passw2 = hashlib.sha3_512(passw2).hexdigest()
        print("usu="+usu)
        print("pusu="+passw2)
        respuesta = controlador.validar_usuario(usu, passw2)
        global email_origen

        if(len(respuesta)==0):
            email_origen=""
            mensaje="Oppsss!! ERROR DE AUTENTICACIÓN! Lo invitamos a verificar sus credenciales....!!!!"
            return render_template("informacion.html", datas=mensaje)
        else:
            email_origen=usu
            respuesta2 = controlador.listaDestinatarios(usu)
            return render_template("principal.html",datas=respuesta2,infousu=respuesta)

@app.route("/registrarUsuario", methods=["GET", "POST"])
def registrarUsuario():
    if request.method=="POST":
        name=request.form["txtnombre"]
        name=name.replace("''","=======0000===37373==").replace("SELECT","").replace("UPDATE","").replace("DELETE","").replace("DROP","").replace("INSERT","").replace("select","").replace("update","").replace("delete","").replace("drop","").replace("insert","")
        email=request.form["txtusuarioregistro"]
        passw=request.form["txtpassregistro"]  
        passw2=passw.encode() 
        passw2 = hashlib.sha3_512(passw2).hexdigest()

        codigo=datetime.now()
        codigo2=str(codigo)
        codigo2=codigo2.replace("-","")
        codigo2=codigo2.replace(" ","")
        codigo2=codigo2.replace(":","")
        codigo2=codigo2.replace(".","")
        print(codigo2)
        

        respuesta = controlador.crear_usuario(name, email, passw2, codigo2)
        if respuesta == "1":
            mensaje="Sr, usuario su codigo de activacion es :\n\n"+codigo2+ "\n\n Recuerde copiarlo y pegarlo para validarlo en la seccion de login y activar su cuenta.\n\nMuchas Gracias"
            resp=envioemail.enviar(email, mensaje, "Código de Activación")
            if resp=="1":
                mensaje="Usuario registrado satisfactoriamente"
            else:
                mensaje="usuario registrado satisfactoriamente. se presentó un error al enviar el código de activación. Utilice el siguiente código: :\n\n"+codigo2+ ""            
        else:
            mensaje="ERRORR. El usuario ya existe!"

        return render_template("informacion.html", datas=mensaje)


@app.route("/activarUsuario", methods=["GET", "POST"])
def activarUsuario():
    if request.method=="POST":
        codigo=request.form["txtcodigo"] 

        respuesta = controlador.activar_usuario(codigo)
        if(len(respuesta)==0):
            mensaje="El código de activación es erroneo, verifiquelo!!"            
        else:
            mensaje="El usuario se ha activado exitosamente!!"
        return render_template("informacion.html", datas=mensaje)

@app.route("/enviarEmail", methods=["GET", "POST"])
def enviarEmail():
    if request.method=="POST":
        emailDestino=request.form["emailDestino"]
        asunto=request.form["asunto"]
        mensaje=request.form["mensaje"]

        controlador.registrar_email(asunto, mensaje, email_origen, emailDestino)

        mensaje2="Estimado usuario, usted recibió un email, por favor ingrese a la plataforma para observar el mensaje, en la pestaña Historial\n\nMuchas gracias."
        envioemail.enviar(emailDestino, mensaje2, "Nuevo mensaje enviado")

        return "Email enviado satisfactoriamente."

@app.route("/verHistorial", methods=["GET", "POST"])
def verHistorial():
    if request.method=="POST": 
        respuesta = controlador.ver_enviados(email_origen)
        return render_template("respuesta.html", datas=respuesta)

@app.route("/actualizacionPassword", methods=["GET", "POST"])
def actualizacionPassword():
    if request.method=="POST": 
        pass1= request.form["pass"]
        passw2=pass1.encode() 
        passw2 = hashlib.sha3_512(passw2).hexdigest()
        controlador.actualizar_password(passw2, email_origen)
        return "Actualización exitosa"
    
